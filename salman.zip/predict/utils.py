import numpy as np
import pandas as pd
import tensorflow as tf
import tensorflow_io as tfio
import librosa
import cv2


def extract_mfcc(path):
    audio, sr = librosa.load(path, sr=44100, duration=4, mono=True)
    if len(audio) < 4 * sr:
        audio = np.pad(audio, pad_width=(0, 4 * sr - len(audio)), mode='constant')
    signal = librosa.feature.mfcc(y=audio, sr=sr, n_mfcc=128)
    image = np.expand_dims(signal, axis=-1)
    image = np.repeat(image, 3, axis=-1)
    image_resized = cv2.resize(image, (300, 300))
    return np.array(image_resized)


def load_data(file):
    spectrogram = extract_mfcc(file)
    spectrogram = np.array(spectrogram)
    spectrogram = np.expand_dims(spectrogram, axis=0)
    return spectrogram


def create_model():
    model = tf.keras.Sequential([
        tf.keras.layers.Conv2D(32, (3, 3), activation='relu', input_shape=(300, 300, 3), padding='same'),
        tf.keras.layers.MaxPooling2D((2, 2)),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.Conv2D(64, (3, 3), activation='relu', padding='same'),
        tf.keras.layers.MaxPooling2D((2, 2)),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.GlobalAveragePooling2D(),
        tf.keras.layers.Dropout(0.5),
        tf.keras.layers.Dense(64, activation='relu'),
        tf.keras.layers.Dense(7, activation='softmax')
    ])

    return model
