from django.shortcuts import render
from django.conf import settings
from tensorflow.keras.models import load_model
from django.http import HttpResponseForbidden

from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.renderers import JSONRenderer
from rest_framework import status
from rest_framework.response import Response

from pydub import AudioSegment
from shutil import copyfileobj

import os
import tempfile

from .utils import *
from .serializer import *

class PredictEndPoint(APIView):
    model = None
    parser_classes = (MultiPartParser, FormParser)
    data_dict = {0: 'tepat', 1: 'tidak_tepat'}
    renderer_classes = [JSONRenderer, ]
    allowed_file_extension = ['mp3', 'wav', 'mp4', 'm4a']

    @classmethod
    def load_model(cls):
        if cls.model is None:
            model_path = os.path.join(settings.MEDIA_ROOT, 'target_recognition_mfcc.h5')
            if os.path.exists(model_path):
                try:
                    cls.model = create_model()
                    cls.model.load_weights(model_path)
                    cls.model.summary()
                except Exception as e:
                    print("Error loading model:", e)
                finally:
                    print('Model loaded')
            else:
                print("Model file not found at:", model_path)
        return cls.model

    def get(self, *args, **kwargs):
        return HttpResponseForbidden()

    def post(self, *args, **kwargs):
        file_serializer = FileUploadSerializer(data=self.request.data)
        if file_serializer.is_valid():
            uploaded_file = self.request.FILES['file']
            ext_name: str = uploaded_file.name.split('.')[-1]

            if ext_name in self.allowed_file_extension:
                audio = AudioSegment.from_file(uploaded_file)
                with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as temp_file:
                    audio.export(temp_file.name, format='wav')
                    temp_filename = temp_file.name
            else:
                msg_list = [f".{x}" for x in self.allowed_file_extension]
                msg = ' or '.join(msg_list)
                return Response({'error': f"File format extension not supported! Only {msg} are supported!"},
                                status=status.HTTP_403_FORBIDDEN)

            try:
                data = load_data(temp_filename)

                pred = self.load_model().predict(data)
                prediction = np.argmax(pred)
                confidence = np.max(pred)
                confidence = 100.0 if confidence * 100 > 1.0 else confidence
                pred_result = self.data_dict[prediction]

            finally:
                if os.path.exists(temp_filename):
                    os.remove(temp_filename)

            save_dir = os.path.join(settings.MEDIA_ROOT, 'result', str(prediction))
            if not os.path.exists(save_dir):
                os.makedirs(save_dir, exist_ok=True)

            save_path = os.path.join(save_dir, uploaded_file.name)
            with open(save_path, 'wb+') as destination:
                copyfileobj(uploaded_file, destination)

            return Response(data={'predictions': pred_result, 'confidence': confidence},
                            status=status.HTTP_200_OK)

        return Response({'error': file_serializer.errors['file']}, status=status.HTTP_400_BAD_REQUEST)
